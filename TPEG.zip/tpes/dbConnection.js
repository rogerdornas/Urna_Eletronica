const mysql = require("mysql");

const pool = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "jei12e42134h234r2$IH#h4iaw4e",
  database: "elections",
});

module.exports = pool;